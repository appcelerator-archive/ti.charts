// Ensure that the charts module is loaded
var Charts = require('ti.charts');

// Open the main category selection page
require('navigator').start(Charts);